<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Online Hostel Management System Password Retriever">
    <title>HMS-SKLM | Reset Password</title>
    <link rel="shortcut icon" href="imgs/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/mobile.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
</head>

<body>
    <div class="home">
        <div class="nav">
            <div class="bg"></div>
            <div class="logo">
                <div class="img"><img src="imgs/logo.png" alt="HMS"></div>
                <div class="title">Hostel Management System</div>
            </div>
            <div class="mbl">
                <div class="title">HMS-SKLM</div>
                <div class="bars">
                    <img src="imgs/bars2.png" alt="Menu">
                </div>
            </div>
            <div class="social">
                <div>
                    <span>Email : chiefwarden@rguktsklm.ac.in</span>
                </div>
                <div>
                    <span>Contact : 6305938893</span>
                </div>
            </div>
            <div class="links">
                <div onclick="url('home.php')" class="active"><i class="fas fa-university"></i>&nbsp;&nbsp;Home</div>
                <div onclick="url('notices.php')"><i class="fas fa-bullhorn"></i>&nbsp;&nbsp;Notices</div>
                <div onclick="url('about.php')"><i class="fas fa-users"></i>&nbsp;&nbsp;About</div>
            </div>
        </div>
        <div class="center" style="margin-top:4%;">
            <div class="container registrations">
                <div class="login" style="background:white;">
                    <form action="" method="post">
                        <h1>HMS-SKLM Reset Password</h1>
                        <div class="msg">
                            
                                                    </div>
                        <div>
                            <label for="uid">Login Id : </label>
                            <input type="text" name="uid" id="uid" placeholder="Will be Used for Logging In" required>
                        </div>
                        <div>
                            <label for="bid">Biometric ID : </label>
                            <input type="text" name="bid" id="bid" placeholder="Your Aadhar ID" required>
                        </div>
                        <div>
                            <label for="sec">Security Key : </label>
                            <input type="text" name="skey" id="sec" placeholder="Your Security Key" required>
                        </div>
                        <div>
                            <label for="psd">New Password : </label>
                            <input type="password" name="psd" id="psd" placeholder="Enter New Password" required>
                        </div>
                        <div>
                            <label for="cpsd">Retype Password : </label>
                            <input type="password" name="cpsd" id="cpsd" placeholder="Confirm Password" required>
                        </div>
                        <div class="submit">
                            <button type="submit" name="reset"><i class="fas fa-pencil-alt"></i>&nbsp;&nbsp;Reset</button>
                        </div>
                        <div class="link">
                            <span>Want to Login? <a href="home.php">Click Here</a></span>
                        </div>
                    </form>
                </div>
            </div>
        </div><br><br><br>
        <div class="footer">
            <span class="cpr">&copy; 2021, All Rights Reserved RGUKT-Srikakulam.</span>
            <span class="tgl" onclick="newtab('https://www.linkedin.com/in/venkata-kiran-jakkapu-a2209415a?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BD0udCu37TJGDP2MUF8aDuw%3D%3D')"><i class="fas fa-info-circle"></i></span>
            <div class="developer">
                <div class="info">
                    <span class="head">Designer & Developer</span>
                    <span class="img">
                        <img src="imgs/developer.jpg" alt="S160204">
                    </span>
                    <span class="data">J. Venkata Kiran (S160204)</span>
                    <span class="data">ECE-4D</span>
                    <!-- <span class="child">Student From Dept. of <span>ECE (04)</span></span> -->
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>
    <script>
        $('div.nav div.bars').click(function() {
            $('div.nav div.links').toggleClass('active');
        })

        function url(url) {
            window.location = url;
        }
    </script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0027'},{'id':'4877226'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>