<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Online Hostel Management System RGUKT-SKLM Members">
    <title>HMS-SKLM | ABOUT</title>
    <link rel="shortcut icon" href="imgs/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/mobile.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
</head>

<body>
    <div class="home">
        <div class="nav">
            <div class="bg"></div>
            <div class="logo">
                <div class="img"><img src="imgs/logo.png" alt="HMS"></div>
                <div class="title">Hostel Management System - Srikakulam</div>
            </div>
            <div class="mbl">
                <div class="title">HMS-SKLM</div>
                <div class="bars">
                    <img src="imgs/bars2.png" alt="Menu">
                    <!-- <img src="imgs/bars1.png" alt="Menu"> -->
                </div>
            </div>
            <div class="social">
                <div>
                    <span>Email : chiefwarden@rguktsklm.ac.in</span>
                </div>
                <div>
                    <span>Contact : 6305938893</span>
                </div>
            </div>
            <div class="links">
                <div onclick="url('home.php')"><i class="fas fa-university"></i>&nbsp;&nbsp;Home</div>
                <div onclick="url('notices.php')"><i class="fas fa-bullhorn"></i>&nbsp;&nbsp;Notices</div>
                <div onclick="url('about.php')" class="active"><i class="fas fa-users"></i>&nbsp;&nbsp;About</div>
            </div>
        </div>
        <div class="body about">
            <div class="contain">
                <div class="pair">
                    <h1>-: Chief Wardens :-</h1>
                                        <div class="card main">
                        <div class="profile">
                            <img src="./services/imgs/profiles/62261efcea2560.07113954.tpist photo.jpg" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Ch. Lakshmi Bala</span>
                                <span class="child">Chief Warden RGUKT-SKLM</span>
                                <span class="content">Asst.Prof from Department of CSE</span>
                                <span class="content">lakshmibala@rguktsklm.ac.in</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                                            <div class="card main">
                        <div class="profile">
                            <img src="./services/imgs/profiles/62c949069709c1.08560391.dileep__.jpg" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Mr. Dileep Kumar Koda</span>
                                <span class="child">DSW RGUKT-SKLM</span>
                                <span class="content">Asst.Prof from Department of CSE</span>
                                <span class="content">dileep@rguktsklm.ac.in</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                                            <h1>-: Hostel Wardens :-</h1>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Chaitanyatv</span>
                                <span class="child"><b>2017-B</b> Hostel Warden</span>
                                <span class="content">Asst.Prof from Department of </span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Vasundhara</span>
                                <span class="child"><b>2017-G</b> Hostel Warden</span>
                                <span class="content">Asst.Prof from Department of </span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">V. Pavani</span>
                                <span class="child"><b>2017-G</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Warden-2018-b</span>
                                <span class="child"><b>2018-B</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/62e4c21b05db34.84148236.20220511_063207.jpg" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">GADDALA JAYARAJU</span>
                                <span class="child"><b>2018-B</b> Hostel Warden</span>
                                <span class="content">Asst.Prof from Department of </span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Y Lakshmi Prasanna</span>
                                <span class="child"><b>2018-G</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Bhargavi Boopathi</span>
                                <span class="child"><b>2018-G</b> Hostel Warden</span>
                                <span class="content">Asst.Prof from Department of </span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">M Mounika</span>
                                <span class="child"><b>2018-G</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                                            <h1>-: Caretakers :-</h1>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Caretaker-E3-Boys</span>
                                <span class="child"><b>2017-B (Active)</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Caretaker-E3-Girls</span>
                                <span class="child"><b>2017-G (Active)</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Caretaker-E2-Boys</span>
                                <span class="child"><b>2018-B (Active)</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="profile">
                            <img src="./services/imgs/profiles/thumbCopy.png" alt="Profile">
                        </div>
                        <div class="info">
                            <div class="data">
                                <span class="head">Caretaker-E2-Girls</span>
                                <span class="child"><b>2018-G (Active)</b> Hostel Warden</span>
                                <span class="content">Non-Teaching Staff RGUKT-SKLM</span>
                            </div>
                            <div class="social">
                                <i class="fab fa-linkedin-in"></i>
                                <i class="fab fa-twitter"></i>
                                <i class="fab fa-instagram"></i>
                            </div>
                        </div>
                    </div>
                                    </div>
            </div>
        </div>
        <div class="footer">
            <span class="cpr">&copy; 2021, All Rights Reserved RGUKT-Srikakulam.</span>
            <span class="tgl" onclick="newtab('https://www.linkedin.com/in/venkata-kiran-jakkapu-a2209415a?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BD0udCu37TJGDP2MUF8aDuw%3D%3D')"><i class="fas fa-info-circle"></i></span>
            <div class="developer">
                <div class="info">
                    <span class="head">Designer & Developer</span>
                    <span class="img">
                        <img src="imgs/developer.jpg" alt="S160204">
                    </span>
                    <span class="data">J. Venkata Kiran (S160204)</span>
                    <span class="data">ECE-4D</span>
                    <!-- <span class="child">Student From Dept. of <span>ECE (04)</span></span> -->
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>
    <script>
        $('div.nav div.bars').click(function() {
            $('div.nav div.links').toggleClass('active');
        })

        function url(url) {
            window.location = url;
        }
    </script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0027'},{'id':'4877226'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>