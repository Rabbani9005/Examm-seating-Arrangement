<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Hostel Management System RGUKT Srikakulam">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hostel Management System | RGUKT-Srikakulam</title>
    <link rel="shortcut icon" href="imgs/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/mobile.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
</head>

<body>
    <div class="home">
        <div class="nav">
            <div class="bg"></div>
            <div class="logo">
                <div class="img"><img src="imgs/logo.png" alt="HMS"></div>
                <div class="title">Hostel Management System - Srikakulam</div>
            </div>
            <div class="mbl">
                <div class="title">HMS-SKLM</div>
                <div class="bars">
                    <img src="imgs/bars2.png" alt="Menu">
                </div>
            </div>
            <div class="social">
                <div>
                    <span>Email : chiefwarden@rguktsklm.ac.in</span>
                </div>
                <div>
                    <span>Contact : 6305938893</span>
                </div>
            </div>
            <div class="links">
                <div onclick="url('home.php')" class="active"><i class="fas fa-university"></i>&nbsp;&nbsp;Home</div>
                <div onclick="url('notices.php')"><i class="fas fa-bullhorn"></i>&nbsp;&nbsp;Notices</div>
                <div onclick="url('about.php')"><i class="fas fa-users"></i>&nbsp;&nbsp;About</div>
            </div>
        </div>
        <div class="index">
            <!-- <div class="login">
                <div class="norms">
                    <h1>-: Leave Criteria's :-</h1>
                    <ul>
                        <li><span>1.</span> No Need To Apply Leave For University Holidays.</li>
                        <li><span>2.</span> Students Who Went for Outings Should Return Before 7PM.</li>
                        <li><span>3.</span> Students Who Are In Leaves Should Return to Campus After The Completion Of Due Date.</li>
                        <li><span>4.</span> Disciplainary Actions Will Be Taken For Those Students Who Did Not Return After Due.</li>
                        <li><span>5.</span> Now you can start using Apache, MariaDB, PHP and other components. getting started with PHP applications.</li>
                    </ul>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <h1>-: Login :-</h1>
                    <div class="msg">
                                                
                                            </div>
                    <div class="grid">
                        <label for="uid">UserID : </label>
                        <input type="text" name="uid" id="uid" placeholder="University Id" required autofocus>
                    </div>
                    <div class="grid">
                        <label for="bid">Biometric : </label>
                        <input type="text" name="bid" id="bid" placeholder="Aadhar Number" required>
                    </div>
                    <div class="grid">
                        <label for="pass">Password : </label>
                        <input type="password" name="passwd" id="pass" placeholder="Password" required>
                    </div>
                    <div class="submit">
                        <button type="submit" name="login"><i class="fas fa-sign-in-alt"></i>&nbsp;&nbsp;Login</button>
                    </div>
                </form>
            </div> -->
            <div class="center">
                <div class="container">
                    <div class="regulations">
                        <h1>-: Rules You Should Know :-</h1>
                        <ul>
                            <li><span>1.</span> No Need To Apply Leave For University Holidays.</li>
                            <li><span>2.</span> Students Who Went for Outings Should Return Before 7PM.</li>
                            <li><span>3.</span> Students Who Are In Leaves Must Return to Campus After The Completion Of Due Date.</li>
                            <li><span>4.</span> Disciplainary Actions Will Be Taken For Those Students Who Did Not Return After Due Date.</li>
                            <li>
                                <span>5.</span>
                                Check your leave/outing history in HMS account everytime you report to campus.
                                If entry at the main-gate is missing then you have to meet the security on the same day.
                                Otherwise, you are considered on leave until your reporting date is entered by the security.
                                Ensure proper entry of your leaves/outings. This data is used for epass scholarship attendance.
                            </li>
                        </ul>
                    </div>
                    <div class="login">
                        <h1>Login Here</h1>
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="msg">
                                
                                                            </div>
                            <div>
                                <label for="uid">UserId : </label>
                                <input type="text" name="uid" id="uid" placeholder="UserId" value="" required>
                            </div>
                            <div>
                                <label for="bid">Biometric Id : </label>
                                <input type="text" name="bid" id="bid" placeholder="Aadhar Id" value="" required>
                            </div>
                            <div>
                                <label for="pass">Password : </label>
                                <input type="password" name="passwd" id="pass" placeholder="Password" value="" required>
                            </div>
                            <div class="submit">
                                <button type="submit" name="login"><i class="fas fa-sign-in-alt"></i>&nbsp;&nbsp;Login</button>
                            </div>
                            <div class="link">
                                <span>Forgot Password? <a href="forgot.php">Click Here</a></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <span class="cpr">&copy; 2021, All Rights Reserved RGUKT-Srikakulam.</span>
            <span class="tgl" onclick="newtab('https://www.linkedin.com/in/venkata-kiran-jakkapu-a2209415a?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BD0udCu37TJGDP2MUF8aDuw%3D%3D')"><i class="fas fa-info-circle"></i></span>
            <div class="developer">
                <div class="info">
                    <span class="head">Designer & Developer</span>
                    <span class="img">
                        <img src="imgs/developer.jpg" alt="S160204">
                    </span>
                    <span class="data">J. Venkata Kiran (S160204)</span>
                    <span class="data">ECE-4D</span>
                    <!-- <span class="child">Student From Dept. of <span>ECE (04)</span></span> -->
                </div>
            </div>
        </div>
    </div>
    <div class="modal">
        <div class="bg"></div>
        <div class="content">
            <h1><u>-: Our Sincere & Heartful Thanks To :-</u></h1>
            <div class="master">
                <div class="profile"></div>
                <h1>Honourable Chancellor Sir <q>Prof. K.C.Reddy</q> Garu</h1>
                <p class="text"><q>Professor K.C.Reddy, a Doctorate in Economics; Taught Economics at Andhra University for over three decades; Acclaimed as a Teacher and Researcher par excellence by his students and peers; Authored many books and papers; Occupied several administrative positions like Director, Academic Staff College, and SAARC Studies Centre; Board of Management Member and Vice-Chancellor-in-charge at Andhra University; Chairman, A.P.State Council of Higher Education for two terms; Visiting Professor at Armstrong Atlantic State University, Savannah, Georgia, U.S.A. As an education administrator, introduced many innovative measures in Higher Education; Provided Leadership as the Founder Vice-Chancellor of Rajiv Gandhi University of Knowledge Technologies; Also served as Chairman, Rajiv Yuva Kiranalu, a flagship Skill Development and Employment Programme of united A.P.Government during 2011-14 and instrumental in skill up gradation in providing employment to unemployed. Recipient of many awards and honours across India and abroad. To make a special mention – President’s Award for Innovation in Higher Education from Indian Science Congess; Hony. D.Litt. from Bleakinge Institute of Technology, Sweden.</q></p>
            </div>
            <div class="child">
                <div class="data" style="display: unset;">
                    <div class="img" style="width: 180px;height: 180px;float:left;margin:.5em 1.5em;"><img src="imgs/dir.png" alt=""></div>
                    <h1>Our Director <q>Prof.P.Jagadeeswara Rao</q> Garu <sub><span style="margin: unset;">RGUKT Srikakulam.</span></sub></h1>
                    <span>Ph.D.inWatershed Management, Andhra University, Visakhapatnam 1998; M.Tech(RS & GIS) CSSTEAP, UNO (Affiliated)-2007; Post M.Sc.(Tech) Hydrogeology (AU,1990); M.Sc (Geology) Andhra University, 1986; Course on Disaster Management (CSSTEAP, UNO Affiliated); TrainedonMDP (ALP) in IIM-Kozhikode.</span>
                </div>
                <div class="data">
                    <div class="img">
                        <img src="imgs/aosklm.png" alt="" style="object-position: top center;">
                    </div>
                    <div class="info">
                        <h1>Administrative Officer <q>Mr. K Mohana Krishna Chowdary</q> Garu</h1>
                        <span><q>Administrative Officer - RGUKT, Srikakulam</q></span>
                        <span><q>ao@rguktsklm.ac.in </q></span>
                    </div>
                </div>
            </div>
            <div class="close" title="Click To Close!">
                <span>X</span>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/main.js"></script>
    <script>
        $('div.nav div.bars').click(function() {
            $('div.nav div.links').toggleClass('active');
        })

        function url(url) {
            window.location = url;
        }

        function Modal() {
            $('div.modal').addClass('active');
            $('body').css('overflow','hidden');
        }

        
        $('div.modal div.close').click(function() {
            $('div.modal').removeClass('active');
            setTimeout(() => {
                $.ajax({
                    url: 'base.php?type=modal',
                    success: (data) => {
                        $('body').css('overflow','');
                    }
                });
            }, 100);
        })
    </script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0027'},{'id':'4877226'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>